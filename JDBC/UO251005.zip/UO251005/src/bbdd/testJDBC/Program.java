package bbdd.testJDBC;
import java.util.Collections;
import java.util.LinkedList;
import java.util.Scanner;
import java.sql.*;

import org.hsqldb.types.Types;

public class Program {
	public final static String URL = "jdbc:hsqldb:hsql://localhost/labdb";
	static Connection con ;
	static Statement st ;

	public static void main(String[] args) {		
		try {
			connect();
			
			exercise1();
			exercise2();
			exercise3();
			unconnect();
			
		} catch (SQLException e) {			
			System.err.println("SQL Exception " + e.getMessage());
			e.printStackTrace();
		}
	}
	
	private static void unconnect() throws SQLException {
		st.close();
		con.close();
		
	}

	public static void connect() throws SQLException{
		con = DriverManager.getConnection(URL,"SA","");
		st =  con.createStatement();
	}
		
	/*	 
		1. La DGT ha decidido acortar en cierto porcentaje las carreteras
		 que han sufrido m�s de cierto n�mero de incidentes de tipo salida de v�a o choques.
		  Realizar un m�todo que para un porcentaje y n�mero de incidentes determinado (par�metros) 
		  acorte la longitud de las carreteras en dicho porcentaje siempre y cuando en esa carretera
		   hayan ocurrido m�s incidentes de tipo salida de v�a o choques que el par�metro recibido. 
		   El m�todo debe mostrar por pantalla tambi�n el n�mero de carreteras modificadas.
		1. The traffic police has decided to shorten in a certain percentage the roads that have 
		suffered more than a certain number of incidents of the types �salida de via� (road departure)
		 or �choque� (crash). Create a method that, for a given percentage and number of incidents
		  (parameters), shortens the length of the roads in that percentage, provided that more incidents 
		  of the types �salida de via� or �choque� occurred on the road than the received parameter.
		   The method must print on the screen the number of modified roads.
	 */
	public static void exercise1() throws SQLException{		
		System.out.println("################### EXERCISE 1 ###################");		
		System.out.println("please introduce the nincidents limit");
		int nIncidents =ReadInt();
		System.out.println("please introduce the percentage to shorten the road");
		double percentage = ReadDouble();
		String query = "update road "
				+ "set LENGTH_ROAD = LENGTH_ROAD * ? "
				+ "where ID_ROAD in ("
				+ " select  r.ID_ROAD "
				+ "FROM road r,TSECTION s, INCIDENT i	"
				+ "where s.ORDER_ROAD = i.ORDER_ROAD "
				+ "and r.ID_ROAD = s.ID_ROAD "
				+ "and (DESCRIP_INCIDENT = 'salida de via' or DESCRIP_INCIDENT = 'choque' ) "
				+ "GROUP by r.ID_ROAD	"
				+ "having count(i.ID_INCIDENT) > ?)";
		String query2 = "select distinct count(r.ID_ROAD)"
				+ " FROM road r,TSECTION s, INCIDENT i "
				+ "where s.ORDER_ROAD = i.ORDER_ROAD	"
				+ "and r.ID_ROAD = s.ID_ROAD "
				+ "and (DESCRIP_INCIDENT = 'salida de via' or DESCRIP_INCIDENT = 'choque' ) "
				+ "GROUP by r.ID_ROAD "
				+ "having count(i.ID_INCIDENT) > 3";
		ResultSet rs = st.executeQuery(query2);
		PreparedStatement psQuery = con.prepareStatement(query);
		psQuery.setDouble(1, percentage);
		psQuery.setInt(2, nIncidents);
		psQuery.executeUpdate();
		LinkedList<Integer> updated = new LinkedList<Integer>();;
		while(rs.next()){
			updated.add(Integer.parseInt(rs.getString(1)));
		}
		int max = Collections.max(updated);
		System.out.println("updated roads = "+max);
		rs.close();
		psQuery.close();
	}
	
	/*
	   	2. Crear un m�todo que muestre por pantalla las etapas de monta�a de categor�a especial. 
	   	De cada una de ellas debe mostrarse el n�mero de etapa, la altitud y la longitud, as�
	   	 como el n�mero de ciclistas que la disputan que pertenecen a equipos que reciben subvenciones
	   	  de m�s de 100000�. Adem�s, deben mostrarse para cada una de ellas, los tramos por los que pasa,
	   	   la longitud de los mismos y el tipo de carretera de cada uno de los tramos.
	   	2. Create a method that prints on the screen the mountain stages of category �especial�.
	   	 For each of them, the method must show the stage number, the altitude and the length in km,
	   	  as well as the number of cyclists that belong to teams with a sponsored amount of more than
	   	   100000� that take part in it. Also, for each one of them, the method must show the sections
	   	    by which it passes, their length and the type of the road of each one of the sections.
	 */
	
	public static void exercise2() throws SQLException {		
		System.out.println("################### EXERCISE 2 ###################");		
		String q1 ="select  s.NUM_STAGE,ms.altitude ,s.km  from stage s ,MOUNTAINSTAGE ms "
				+ "where ms.NUM_STAGE = s.NUM_STAGE "
				+ "and ms.CATEGORY_MOUNTAIN = 'especial' "
				+ "order by km desc ";
		
		String q2 = "select count(c.CYCLIST_name)"
				+ " from TAKES_PART tp,CYCLIST c, TEAM t, IS_SPONSORIZED isp "
				+ "where tp.NUM_STAGE = ? "
				+ "and tp.CYCLIST_NAME = c.CYCLIST_NAME "
				+ "and c.NAME_TEAM = t.NAME_TEAM "
				+ "and t.NAME_TEAM = isp.NAME_TEAM "
				+ "and isp.AMOUNT >= 100000";
		
		String q3 = "select s.ORDER_ROAD, s.LENGTH_SECTION, r.TYPE_ROAD "
				+ "from tsection s, road r,GOES_BY gb "
				+ "where gb.NUM_STAGE = ? "
				+ "and gb.ORDER_ROAD = s.ORDER_ROAD "
				+ "and s.ID_ROAD = r.ID_ROAD";
		ResultSet rs1 = st.executeQuery(q1);
		while(rs1.next()){
			String num_stage = rs1.getString(1);
			String altitude = rs1.getString(2);
			String km = rs1.getString(3);
			PreparedStatement psQuery1 = con.prepareStatement(q2);
			psQuery1.setString(1, num_stage);
			ResultSet rs2 = psQuery1.executeQuery();
			while(rs2.next()){
				String num_cyclist = rs2.getString(1);
				System.out.println("-MountainStage: "+ num_stage+ " "+altitude+ " " +km+" " +num_cyclist);
				PreparedStatement psQuery2 = con.prepareStatement(q3);
				psQuery2.setString(1, num_stage);
				ResultSet rs3= psQuery2.executeQuery();
				
				while(rs3.next()){
					String orderRoad = rs3.getString(1);
					String length = rs3.getString(2);
					String typeRoad = rs3.getString(3);
					System.out.println("\tSection: "+orderRoad+" "+length+" "+ typeRoad);
				}
			}
			
		}
		rs1.close();//all the rest is closed
	}

	
	/*	
		3. Invocar desde Java al procedimiento incidente_tramo (ya definido en la base de datos) que, dado el id de un incidente, devuelve el tramo en el que tuvo lugar. Adem�s devuelve la longitud de dicho tramo. Mostrar por pantalla la informaci�n obtenida.
		3. Invoke from Java the stored procedure incidente_tramo (already defined in the database) which, given the id of an incident, returns the section where it took place. It also returns the length of that section. Print on the screen the obtained information.
		PROCEDURE incidente_tramo(
			idinc IN incidente.id_incidente%TYPE,       / idinc IN incident.id_incidente%TYPE, 
			ordencarr OUT tramo.orden_carretera%TYPE,   / orderroad OUT section.order_road%TYPE, 
			idcarr OUT tramo.id_carretera%TYPE,         / idroad OUT section.id_road%TYPE, 
			longitudtra OUT tramo.longitud_tramo%TYPE)  / lenghtsection OUT section.length%TYPE)

	 
	 */
	public static void exercise3() throws SQLException {		
		System.out.println("################### EXERCISE 3 ###################");		
		CallableStatement cst = con.prepareCall("{call INCIDENTE_TRAMO(?,?,?,?)}");
		System.out.println("Please introduce the desired ID to execute the procedure");
		String readedID = ReadString();
		cst.setString(1, readedID);
		cst.registerOutParameter(2, Types.VARCHAR);
		cst.registerOutParameter(3, Types.VARCHAR);
		cst.registerOutParameter(4, Types.VARCHAR);
		cst.execute();
		StringBuilder builder = new StringBuilder();
		builder.append(cst.getString(2)+"  ");
		builder.append(cst.getString(3)+"  ");
		builder.append(cst.getString(4)+"  ");
		System.out.println(builder.toString());
		
		cst.close();
	}
	

    // ------------------- DATABASE UTILS -------------------
	
	
	@SuppressWarnings("resource")
	private static String ReadString(){
		return new Scanner(System.in).nextLine();		
	}
	
	@SuppressWarnings("resource")
	private static int ReadInt(){
		return new Scanner(System.in).nextInt();			
	}

    @SuppressWarnings("resource")
	private static Double ReadDouble(){
		return new Scanner(System.in).nextDouble();			
	}	
}
